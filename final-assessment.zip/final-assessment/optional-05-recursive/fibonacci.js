function fibonacci(n) {
    if (n === 0) {
        return [0];
    } else if (n === 1) {
        return [0, 1];
    }

    const fibSeries = fibonacci(n - 1);
    fibSeries.push(fibSeries[n - 1] + fibSeries[n - 2]);
    return fibSeries;
}

// Jangan hapus kode di bawah ini!
export default fibonacci;