import { sum } from './index.js';
import { strict as assert } from 'node:assert';
import test from 'node:test';

test('sum menambahkan dua angka positif', () => {
  assert.equal(sum(2, 3), 5); // Ekspektasi: 2 + 3 = 5
});

test('sum menambahkan angka positif dan negatif', () => {
  assert.equal(sum(5, -3), 2); // Ekspektasi: 5 + (-3) = 2
});

test('sum menambahkan dua angka negatif', () => {
  assert.equal(sum(-4, -6), -10); // Ekspektasi: -4 + (-6) = -10
});

test('sum menambahkan dengan angka nol', () => {
  assert.equal(sum(0, 5), 5); // Ekspektasi: 0 + 5 = 5
  assert.equal(sum(0, 0), 0); // Ekspektasi: 0 + 0 = 0
});
