import {
    test
} from 'node:test';
import assert from 'node:assert';
import sum from './index.js';

test('sum dengan dua angka positif', () => {
    assert.strictEqual(sum(2, 3), 5);
});

test('sum dengan angka negatif', () => {
    assert.strictEqual(sum(-1, 5), 0);
    assert.strictEqual(sum(4, -3), 0);
    assert.strictEqual(sum(-1, -1), 0);
});

test('sum dengan tipe data yang tidak valid', () => {
    assert.strictEqual(sum('a', 5), 0);
    assert.strictEqual(sum(2, 'b'), 0);
    assert.strictEqual(sum('a', 'b'), 0);
});

test('sum dengan angka nol', () => {
    assert.strictEqual(sum(0, 5), 5);
    assert.strictEqual(sum(0, 0), 0);
    assert.strictEqual(sum(5, 0), 5);
});